#!/bin/bash

script_name=$(basename "$0")

if [ "$script_name" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

log_file="report_${script_name%.*}.log"

echo " $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$log_file"

random_seconds=$(( RANDOM % 1770 + 30 ))

sleep $random_seconds

minutes=$(( random_seconds / 60 ))

echo " $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $minutes минут" >> "$log_file"

exit 0
