#!/bin/bash

CONFIG_FILE="observer.conf"

LOG_FILE="observer.log"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') [ERROR] Конфигурационный файл $CONFIG_FILE не найден" >> "$LOG_FILE"
    exit 1
fi

is_running() {
    local script_name=$1
    for pid in /proc/[0-9]*; do
        if [ -f "$pid/cmdline" ]; then
            if grep -q "$script_name" "$pid/cmdline" 2>/dev/null; then
                return 0
            fi
        fi
    done
    return 1
}

while IFS= read -r script || [ -n "$script" ]; do
    
    script_name=$(basename "$script")
    
    if is_running "$script_name"; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] Процесс $script_name уже запущен" >> "$LOG_FILE"
    else
        nohup "$script" >/dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') [ACTION] Запущен процесс $script_name (PID: $!)" >> "$LOG_FILE"
    fi
done < "$CONFIG_FILE"

exit 0
